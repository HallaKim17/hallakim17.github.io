import sys
from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QWidget, QApplication, QPushButton
from PyQt5 import QtMultimedia

class Example(QWidget):
	def __init__(self):
		super().__init__()
		self.initUI()

	def initUI(self):
	    self.setGeometry(300,300,200,200)
	    self.b1 = QPushButton("Play", self)
	    self.b1.clicked.connect(self.Play)
	    self.b1.move(50,80)


	def Play(self):
		
		self.url = QtCore.QUrl.fromLocalFile("./snare_1.wav")
		self.content = QtMultimedia.QMediaContent(self.url)
		self.player = QtMultimedia.QMediaPlayer()
		self.player.setMedia(self.content)
		self.player.play()
	    #self.QSound.play("./snare_1.wav")
	    


if __name__== '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    print("playing")
    sys.exit(app.exec_())